﻿namespace BinarySerialization.Test.Custom
{
    public class CustomWithContextContainerClass
    {
        public CustomWithContextClass Value { get; set; }
    }
}
