﻿using System;

namespace BinarySerialization.Test.Custom
{
    public class CustomAttribute : Attribute
    {
    }
}
