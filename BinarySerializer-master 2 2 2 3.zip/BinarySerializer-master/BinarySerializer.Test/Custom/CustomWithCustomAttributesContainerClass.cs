﻿namespace BinarySerialization.Test.Custom
{
    public class CustomWithCustomAttributesContainerClass
    {
        [Custom]
        public CustomWithCustomAttributes Value { get; set; }
    }
}
