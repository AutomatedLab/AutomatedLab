﻿namespace BinarySerialization.Test.Custom
{
    public class CustomSubtypeBaseClass
    {
    }
}