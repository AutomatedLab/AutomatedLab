﻿namespace BinarySerialization.Test
{
    public class Zinc : Chemical
    {
        public Zinc() : base("Zn")
        {
        }
    }
}