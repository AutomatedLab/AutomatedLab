﻿using System.Collections.Generic;

namespace BinarySerialization.Test.Subtype
{
    public class RecoverableMissingSubtypeClass<T>
    {
        public List<T> Items { get; set; }
    }
}