namespace BinarySerialization.Test.Subtype
{
    public class SubclassB : Superclass
    {
        public int SomethingForClassB { get; set; }
    }
}