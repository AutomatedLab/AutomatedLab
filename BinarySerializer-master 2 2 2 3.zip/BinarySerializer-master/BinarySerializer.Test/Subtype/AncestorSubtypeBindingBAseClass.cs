﻿namespace BinarySerialization.Test.Subtype
{
    public class AncestorSubtypeBindingBaseClass
    {
    }
}