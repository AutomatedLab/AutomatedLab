namespace BinarySerialization.Test.Subtype
{
    public class SubclassA : Superclass
    {
        public byte SomethingForClassA { get; set; }
    }
}