namespace BinarySerialization.Test.Subtype
{
    public class UnspecifiedSubclass : SubclassB
    {
    }
}