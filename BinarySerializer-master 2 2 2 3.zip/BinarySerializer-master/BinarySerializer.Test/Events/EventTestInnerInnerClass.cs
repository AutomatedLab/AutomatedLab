﻿namespace BinarySerialization.Test.Events
{
    public class EventTestInnerInnerClass
    {
        public ushort Value { get; set; }
    }
}