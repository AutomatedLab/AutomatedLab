﻿namespace BinarySerialization.Test.Unknown
{
    public class UnknownTypeClass
    {
        public object Field { get; set; }
    }
}