﻿namespace BinarySerialization.Test
{
    public class CalciumCarbonate : Chemical
    {
        public CalciumCarbonate() : base("CaCO3")
        {
        }
    }
}