﻿namespace BinarySerialization.Test.Value
{
    public class PngImageHeaderChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
