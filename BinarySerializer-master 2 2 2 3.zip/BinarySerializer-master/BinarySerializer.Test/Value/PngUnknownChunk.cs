﻿namespace BinarySerialization.Test.Value
{
    public class PngUnknownChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
