﻿namespace BinarySerialization.Test.Value
{
    public abstract class PngChunk
    {
    }
}
