﻿namespace BinarySerialization.Test.Value
{
    public class PngImageDataChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
