﻿namespace BinarySerialization.Test.Value
{
    public class PngPaletteChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
