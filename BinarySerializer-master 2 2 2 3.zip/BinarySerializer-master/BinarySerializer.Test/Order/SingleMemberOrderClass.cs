﻿namespace BinarySerialization.Test.Order
{
    public class SingleMemberOrderClass
    {
        public int Field { get; set; }
    }
}