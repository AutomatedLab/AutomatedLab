﻿namespace BinarySerialization.Test.Order
{
    public class MutlipleMembersNoOrderClass
    {
        public int First { get; set; }

        public int Second { get; set; }
    }
}