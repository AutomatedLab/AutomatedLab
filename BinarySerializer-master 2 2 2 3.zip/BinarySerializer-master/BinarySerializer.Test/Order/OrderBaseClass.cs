﻿namespace BinarySerialization.Test.Order
{
    public class OrderBaseClass
    {
        public byte First { get; set; }
    }
}