﻿namespace BinarySerialization.Test.ItemLength
{
    public class LimitedItemLengthClassInnerClass
    {
        public string Value { get; set; }
    }
}