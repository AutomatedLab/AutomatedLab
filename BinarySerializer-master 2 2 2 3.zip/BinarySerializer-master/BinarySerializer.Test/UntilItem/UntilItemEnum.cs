﻿namespace BinarySerialization.Test.UntilItem
{
    public enum UntilItemEnum : byte
    {
        Normal = 0,
        End = 1,
        Header = 2,
    }
}
