﻿using System.Collections.Generic;

namespace BinarySerialization.Test.UntilItem
{
    public class UntilItemContainerDeferred
    {
        public List<Section> Sections { get; set; }
    }
}
