﻿using Xunit;

namespace BinarySerialization.Test.Misc
{
    
    public class RecursiveGraphTests : TestBase
    {
        //[Fact]
        //public void RecursiveGraphTest()
        //{
        //    var expected = new RecursiveGraphClass();
        //    var actual = Roundtrip(expected);
        //}
    }
}