﻿using Xunit;

namespace BinarySerialization.Test.Misc
{
    
    public class AsbtractClassTests : TestBase
    {
        //[Fact]
        //public void AbstractClassTest()
        //{
        //    var container = new AbstractClassContainer {Content = new DerivedClass()};
        //    Roundtrip(container, 4);
        //}
    }
}