﻿namespace BinarySerialization.Test.Misc
{
    public class EmptyClass
    {
    }
}