﻿namespace BinarySerialization.Test.Misc
{
    public class SkipableClass
    {
        public int Value { get; set; }
    }
}
