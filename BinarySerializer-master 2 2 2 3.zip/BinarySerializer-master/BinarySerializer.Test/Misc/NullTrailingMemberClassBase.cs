﻿namespace BinarySerialization.Test.Misc
{
    public class NullTrailingMemberClassBase
    {
        public int BaseValue { get; set; }
    }
}