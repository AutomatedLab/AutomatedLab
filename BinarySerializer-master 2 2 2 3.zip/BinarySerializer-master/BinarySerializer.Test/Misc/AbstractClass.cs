﻿namespace BinarySerialization.Test.Misc
{
    public abstract class AbstractClass
    {
    }
}