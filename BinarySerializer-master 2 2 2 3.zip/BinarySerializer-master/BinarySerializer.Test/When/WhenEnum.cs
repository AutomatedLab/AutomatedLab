﻿namespace BinarySerialization.Test.When
{
    public enum WhenEnum
    {
        WhenOne = 1,
        WhenTwo = 2
    }
}