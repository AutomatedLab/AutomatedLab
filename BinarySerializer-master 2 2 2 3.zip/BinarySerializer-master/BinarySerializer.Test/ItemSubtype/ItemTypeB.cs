﻿namespace BinarySerialization.Test.ItemSubtype
{
    public class ItemTypeB : IItemSubtype
    {
        public byte Value { get; set; }
    }
}
