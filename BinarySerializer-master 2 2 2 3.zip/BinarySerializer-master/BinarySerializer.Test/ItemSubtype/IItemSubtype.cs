﻿namespace BinarySerialization.Test.ItemSubtype
{
    public interface IItemSubtype
    {
    }
}
