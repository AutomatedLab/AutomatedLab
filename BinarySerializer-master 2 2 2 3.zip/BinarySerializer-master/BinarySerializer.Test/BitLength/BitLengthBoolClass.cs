﻿namespace BinarySerialization.Test.BitLength
{
    public class BitLengthBoolClass
    {
        [FieldBitLength(1)]
        public bool Value { get; set; }
    }
}
