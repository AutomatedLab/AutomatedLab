﻿namespace BinarySerialization.Test.Length
{
    public class EmptyInternalClass
    {
    }
}
