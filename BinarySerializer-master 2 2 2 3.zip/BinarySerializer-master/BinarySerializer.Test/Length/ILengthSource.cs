﻿namespace BinarySerialization.Test.Length
{
    public interface ILengthSource
    {
        int Length { get; set; }
    }
}
