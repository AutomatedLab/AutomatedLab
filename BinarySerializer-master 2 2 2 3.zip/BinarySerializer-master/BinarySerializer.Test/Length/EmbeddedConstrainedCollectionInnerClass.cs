﻿using System.Collections.Generic;

namespace BinarySerialization.Test.Length
{
    public class EmbeddedConstrainedCollectionInnerClass
    {
        public List<string> Items { get; set; }
    }
}