namespace BinarySerialization.Test.Enums
{
    public class NamedEnumClass
    {
        public NamedEnumValues Field { get; set; }
    }
}