﻿namespace BinarySerialization.Test.Enums
{
    public enum IncompleteEnumValues
    {
        A,
        B
    }
}