﻿namespace BinarySerialization.Test.Enums
{
    public class IncompleteEnumClass
    {
        public IncompleteEnumValues Field { get; set; }
    }
}