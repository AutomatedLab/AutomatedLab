﻿namespace BinarySerialization.Test.Issues.Issue29
{
    public class BaseCarrierData
    {
    }
}