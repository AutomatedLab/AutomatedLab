﻿namespace BinarySerialization.Test.Issues.Issue12
{
    public abstract class Chunk
    {
    }
}