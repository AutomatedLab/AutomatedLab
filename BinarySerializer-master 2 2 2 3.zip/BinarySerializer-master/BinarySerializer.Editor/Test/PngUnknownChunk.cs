﻿namespace BinarySerializer.Editor.Test
{
    public class PngUnknownChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
