﻿namespace BinarySerializer.Editor.Test
{
    public abstract class PngChunk
    {
    }
}
