﻿using BinarySerialization.Graph.TypeGraph;

namespace BinarySerializer.Editor.ViewModels
{
    public class PrimitiveCollectionViewModelBase : CollectionViewModelBase
    {
        public PrimitiveCollectionViewModelBase(TypeNode typeNode) : base(typeNode)
        {
        }
    }
}
