# Binary Ninja

A new kind of reverse engineering platform

---

[Binary Ninja] is a reverse engineering platform. It focuses on a clean and easy to use interface with a powerful multithreaded analysis built on a custom IL to quickly adapt to a variety of architectures, platforms, and compilers.

[Binary Ninja]: https://binary.ninja/
