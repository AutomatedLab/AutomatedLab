# Interface

## UI

### Zoom
You can change the zoom of level of the graph view by holding CTRL and scrolling with the mouse. 

## Views


## Options


## Hotkeys
