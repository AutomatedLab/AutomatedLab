Architecture
============
.. doxygenclass:: BinaryNinja::Architecture
		:members:
		:protected-members:
