BinaryView
===========
.. doxygenclass:: BinaryNinja::BinaryView
    :members:
