Platform
=========
.. doxygenclass:: BinaryNinja::Platform
