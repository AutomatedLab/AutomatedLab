Binary Ninja C++ API Documentation
==================================

.. toctree::
	:maxdepth: 2

	BinaryView_c++
	Architecture_c++
	Platform_c++
	ConsoleLogging_c++
