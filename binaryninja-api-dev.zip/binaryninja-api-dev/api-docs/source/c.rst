Binary Ninja C API Documentation
================================

