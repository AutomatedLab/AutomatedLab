Console Logging
===============
BNLogLevel
----------
.. doxygenenum:: BNLogLevel

Log
---
.. doxygenfunction:: Log

LogDebug
--------
.. doxygenfunction:: LogDebug

LogInfo
--------
.. doxygenfunction:: LogInfo

LogWarn
--------
.. doxygenfunction:: LogWarn

LogError
--------
.. doxygenfunction:: LogError

LogAlert
--------
.. doxygenfunction:: LogAlert
