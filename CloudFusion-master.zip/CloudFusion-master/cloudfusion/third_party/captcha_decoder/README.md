Captacha-basic-recognition
==========================

Python module that intent to crack basic captcha engines using OpenCV and Pytesser

The complete article is available here : http://robindavid.fr/opencv-tutorial/cracking-basic-captchas-with-opencv.html

All this files require my pytesser module: https://github.com/RobinDavid/Pytesser
