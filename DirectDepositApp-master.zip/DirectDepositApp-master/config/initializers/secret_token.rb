# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DirectDepositApp::Application.config.secret_token = '75f4d0aea8163d33159ba09bdf78415de595f31d72deb17f33b09dcc49bfa4617022f108acdf9b25015f807af7713b32db5c51ee9ba7fdc2a8d3c13ade64027f'
