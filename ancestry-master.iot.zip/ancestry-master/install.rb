puts "Thank you for installing Ancestry. You can visit http://github.com/stefankroes/ancestry to read the documentation."
