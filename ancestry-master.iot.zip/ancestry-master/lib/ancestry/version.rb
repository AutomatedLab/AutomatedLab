module Ancestry
  VERSION = "3.0.5"
end
