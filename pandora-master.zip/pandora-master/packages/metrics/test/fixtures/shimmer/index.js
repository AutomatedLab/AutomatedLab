module.exports = {
  hello() {
    return 'world';
  }
};
