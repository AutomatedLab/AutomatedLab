/**
 * 指标分类
 */

export interface Proxiable {
  type: string;
  proxyMethod: Array<string>;
}
