export const Constants = {
  /**
   * A special number to represent an invalid data
   * 一个特殊的数字来代表一个无效的结果
   */
  NOT_AVAILABLE: -10001
};
