# Metrics API

## Overview

扩展出一堆脱离环境和框架的监控指标，通过简单易用的方式暴露给外部使用方。

具体请参考 Pandora 文档。
