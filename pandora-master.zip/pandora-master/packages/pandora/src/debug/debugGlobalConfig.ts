export default {
  logger: {
    appLogger: {
      stdoutLevel: 'ALL',
      level: 'NONE'
    },
    serviceLogger: {
      stdoutLevel: 'ALL',
      level: 'NONE'
    }
  }
};
