class SomeService {
  start() {
    console.log('start');
  }

  stop() {
    console.log('stop');
  }
};
module.exports = SomeService;



