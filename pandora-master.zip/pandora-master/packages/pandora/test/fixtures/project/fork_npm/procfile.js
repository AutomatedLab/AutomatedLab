module.exports = function (pandora) {
  pandora.fork('app', './app.js');
};
