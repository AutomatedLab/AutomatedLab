console.log('I am x.js');
