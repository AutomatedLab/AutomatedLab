module.exports = function () {
  exports.requireTime = new Date();
};
