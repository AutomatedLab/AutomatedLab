'use strict';

setTimeout(() => {
  process.exit(0);
}, 1000);
