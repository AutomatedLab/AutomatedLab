'use strict';
exports.command = 'reload <appName>';
exports.desc = 'Reload an application';
exports.handler = function (argv) {
  console.log('Coming soon...');
  process.exit(0);
};
