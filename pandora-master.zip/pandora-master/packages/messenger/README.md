# pandora messenger 进程通信模块


