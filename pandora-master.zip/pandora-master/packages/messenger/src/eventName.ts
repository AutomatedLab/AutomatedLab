'use strict';
export default Symbol('message');