export const DEFAULT_HOST = 'localhost';
export const DEFAULT_PORT = 80;
export const HEADER_TRACE_ID = 'x-trace-id';
export const HEADER_SPAN_ID = 'x-span-id';
export const INSTANCE_UNKNOWN = 'unknown';
export const HOST_UNKNOWN = 'UnknownHost';
export const TABLE_UNKNOWN = 'UnknownTable';
export const OPERATION_UNKNOWN = 'other';