module.exports = function (pandora) {

  pandora
    .cluster('./app.js');

};
