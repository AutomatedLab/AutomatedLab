<?php

namespace App\Transformers\Company;

/**
 * @deprecated since 1.2.7 version. use Common\Company instead.
 */
class Company extends \App\Transformers\Common\Company {}
